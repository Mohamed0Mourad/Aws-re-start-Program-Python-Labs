firststring = "hello"
secondstring = "world"
thirdstring = firststring + secondstring
print(thirdstring)

name = input("what is your name: ")
print(name)

color = input("What is your favorite color?  ")
animal = input("What is your favorite animal?  ")

print(f"{name} like {color} {animal}" )