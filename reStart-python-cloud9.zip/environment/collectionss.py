fruitlist = ["apple","banan"]
print(fruitlist)
print(type(fruitlist))
print(fruitlist[0])
fruitlist[1]="peach"
print(fruitlist)

mytuble = ("ali","ahmed","anas")
print(mytuble)
print(type(mytuble))

myFavoriteFruitDictionary = {
  "Akua" : "apple",
  "Saanvi" : "banana",
  "Paulo" : "pineapple"
}
print(myFavoriteFruitDictionary)
print((type(myFavoriteFruitDictionary)))

print(myFavoriteFruitDictionary["Akua"])

print(myFavoriteFruitDictionary["Saanvi"])

print(myFavoriteFruitDictionary["Paulo"])