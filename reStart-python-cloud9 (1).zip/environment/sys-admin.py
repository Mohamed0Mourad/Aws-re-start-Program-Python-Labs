# import os
# os.system("ls")

import subprocess
# subprocess.run(["ls"])
# subprocess.run(["ls","-l"])
# subprocess.run(["ls","-l","numeric.py"])

# Gathering sys info
# subprocess.run(["uname","-a"])

# disk space
# subprocess.run(["df"])

# processes
subprocess.run(['ps',"-X"])