cleanedtext = "malwmrllpllallalwgpdpaaafvnqhlcgshlvealylvcgergffytpktrreaedlqvgqvelgggpgagslqplalegslqkrgiveqcctsicslyqlenycn"
# print(len(cleanedtext))

# print(cleanedtext[:24])
# print(cleanedtext[24:55])
# print(cleanedtext[55:90])
print(cleanedtext[90:111])